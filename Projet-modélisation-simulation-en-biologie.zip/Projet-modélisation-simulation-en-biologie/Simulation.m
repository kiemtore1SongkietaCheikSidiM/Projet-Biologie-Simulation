% ===============================
% Simulation du modèle SEIR + calcul de R0
% ===============================

clear;
clc; 
close all;

% --- Paramètres ---
A     = 100;     % recrutement/naissance
mu    = 0.023;    % taux de mortalité
beta  = 0.6;     % taux de transmission
sigma = 0.4;     % taux de passage E -> I
gamma = 0.15;     % taux de guérison

% --- Conditions initiales ---
S0 = 90;
E0 = 5;
I0 = 5;
R0_init = 0;

Y0 = [S0; E0; I0; R0_init];   % vecteur initial
N0 = sum(Y0); %Nombre totale initiale de la population

% Temps de simulation 

tspan = [0 360];  % [début jusqu'à la fin]

%  Résolution avec ode45 ---La Méthode de Runge-Kutta
[t,Y] = ode45(@(t,Y) seir_model(t,Y,A,mu,beta,sigma,gamma), tspan, Y0);

% Extraction des résultats
S = Y(:,1);
E = Y(:,2);
I = Y(:,3);
R = Y(:,4);

% Calcul de R0 
S_eq = A/mu;  % S0 = A/mu
R0_value = (beta * S_eq * sigma) / (N0 * (mu+sigma) * (mu+gamma));

% Affichage console 
fprintf('Nombre de reproduction de base R0 = %.3f\n', R0_value);
if R0_value < 1
    fprintf('→ L''infection disparaît (équilibre libre stable).\n');
elseif abs(R0_value - 1) < 1e-6
    fprintf('→ Cas critique : l''épidémie est à la limite de persister.\n');
else
    fprintf('→ L''épidémie se propage (équilibre endémique stable).\n');
end

% Tracés des quatres courbes d'évolutions
figure;
plot(t,S,'b','LineWidth',2); hold on;
plot(t,E,'m','LineWidth',2);
plot(t,I,'r','LineWidth',2);
plot(t,R,'g','LineWidth',2);
xlabel('Temps');
ylabel('Population');
title(sprintf('Simulation des quatres variables SEIR (R0 = %.2f)', R0_value));
legend('S (susceptibles)','E (exposés)','I (infectieux)','R (guéris)');
grid on;

% Fonction définissant le système de départ avec les quatres variables 

function dYdt = seir_model(~,Y,A,mu,beta,sigma,gamma)
    S = Y(1); E = Y(2); I = Y(3); R = Y(4);
    N = S + E + I + R;  % population totale

    dS = A - beta*S*I/N - mu*S;
    dE = beta*S*I/N - (mu+sigma)*E;
    dI = sigma*E - (mu+gamma)*I;
    dR = gamma*I - mu*R;

    dYdt = [dS; dE; dI; dR];
end
